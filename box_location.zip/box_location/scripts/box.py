#!/usr/bin/env python3

import rospy
from box_location.srv import Boxlocation
sample_2d_array = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

result_array = []
for row in sample_2d_array:
    for element in row:
        result_array.append(element)
i =0
def handle_request(req):
    print("box is ", result_array[i])
    i = i+1

    return result_array[i-1]
    

def my_service_server():
    rospy.init_node('box_location_server')
    rospy.Service('box_location', int, handle_request)
    rospy.loginfo("box_location is ready.")
    rospy.spin()

if __name__ == '__main__':
    my_service_server()

